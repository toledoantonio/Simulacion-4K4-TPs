﻿
namespace TP1SIM.FrontEnd.Pantallas
{
    partial class Chi_CuadradoCM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtTamañoMuestra = new System.Windows.Forms.TextBox();
            this.btn_generar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_volverMenu = new System.Windows.Forms.Button();
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.tabla = new System.Windows.Forms.DataGridView();
            this.desde = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hasta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cac = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chrt_graf = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lbl_resHipotesis = new System.Windows.Forms.Label();
            this.txtValorTabulado = new System.Windows.Forms.TextBox();
            this.txtNivelSignificancia = new System.Windows.Forms.TextBox();
            this.lblValorTabulado = new System.Windows.Forms.Label();
            this.lblNivelSignificancia = new System.Windows.Forms.Label();
            this.gdrSerieAleatoria = new System.Windows.Forms.DataGridView();
            this.iteracion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rnd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkGyK = new System.Windows.Forms.CheckBox();
            this.checkIncluir1 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.TxtG = new System.Windows.Forms.TextBox();
            this.TxtK = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtM = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtA = new System.Windows.Forms.TextBox();
            this.TxtXo = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.tabla)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chrt_graf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdrSerieAleatoria)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton12.Location = new System.Drawing.Point(291, 146);
            this.radioButton12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(45, 22);
            this.radioButton12.TabIndex = 4;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "12";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton8.Location = new System.Drawing.Point(132, 146);
            this.radioButton8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(37, 22);
            this.radioButton8.TabIndex = 2;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "8";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton10.Location = new System.Drawing.Point(209, 146);
            this.radioButton10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(45, 22);
            this.radioButton10.TabIndex = 3;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "10";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton5.Location = new System.Drawing.Point(55, 146);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(37, 22);
            this.radioButton5.TabIndex = 1;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "5";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 47);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 24);
            this.label1.TabIndex = 7;
            this.label1.Text = "Tamaño de Muestra (N)";
            // 
            // TxtTamañoMuestra
            // 
            this.TxtTamañoMuestra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtTamañoMuestra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTamañoMuestra.Location = new System.Drawing.Point(267, 30);
            this.TxtTamañoMuestra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtTamañoMuestra.Name = "TxtTamañoMuestra";
            this.TxtTamañoMuestra.Size = new System.Drawing.Size(62, 29);
            this.TxtTamañoMuestra.TabIndex = 0;
            // 
            // btn_generar
            // 
            this.btn_generar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_generar.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_generar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_generar.Location = new System.Drawing.Point(159, 773);
            this.btn_generar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_generar.Name = "btn_generar";
            this.btn_generar.Size = new System.Drawing.Size(111, 50);
            this.btn_generar.TabIndex = 14;
            this.btn_generar.Text = "Generar";
            this.btn_generar.UseVisualStyleBackColor = false;
            this.btn_generar.Click += new System.EventHandler(this.btn_generar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(51, 101);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "Numero de Intervalos";
            // 
            // btn_volverMenu
            // 
            this.btn_volverMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volverMenu.Location = new System.Drawing.Point(28, 773);
            this.btn_volverMenu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_volverMenu.Name = "btn_volverMenu";
            this.btn_volverMenu.Size = new System.Drawing.Size(107, 50);
            this.btn_volverMenu.TabIndex = 16;
            this.btn_volverMenu.Text = "Volver al Menu";
            this.btn_volverMenu.UseVisualStyleBackColor = true;
            this.btn_volverMenu.Click += new System.EventHandler(this.btn_volverMenu_Click);
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpiar.Location = new System.Drawing.Point(291, 773);
            this.btn_limpiar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(117, 50);
            this.btn_limpiar.TabIndex = 17;
            this.btn_limpiar.Text = "Limpiar Campos";
            this.btn_limpiar.UseVisualStyleBackColor = true;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // tabla
            // 
            this.tabla.BackgroundColor = System.Drawing.SystemColors.Control;
            this.tabla.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tabla.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.tabla.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tabla.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.tabla.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabla.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.desde,
            this.hasta,
            this.mc,
            this.fo,
            this.fe,
            this.c,
            this.cac});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tabla.DefaultCellStyle = dataGridViewCellStyle2;
            this.tabla.Location = new System.Drawing.Point(316, 30);
            this.tabla.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabla.Name = "tabla";
            this.tabla.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tabla.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.tabla.RowHeadersVisible = false;
            this.tabla.RowHeadersWidth = 51;
            this.tabla.Size = new System.Drawing.Size(1027, 359);
            this.tabla.TabIndex = 18;
            // 
            // desde
            // 
            this.desde.HeaderText = "Lim Inferior";
            this.desde.MinimumWidth = 6;
            this.desde.Name = "desde";
            this.desde.Width = 115;
            // 
            // hasta
            // 
            this.hasta.HeaderText = "Lim Superior";
            this.hasta.MinimumWidth = 6;
            this.hasta.Name = "hasta";
            this.hasta.Width = 125;
            // 
            // mc
            // 
            this.mc.HeaderText = "MC";
            this.mc.MinimumWidth = 6;
            this.mc.Name = "mc";
            this.mc.Width = 125;
            // 
            // fo
            // 
            this.fo.HeaderText = "FO";
            this.fo.MinimumWidth = 6;
            this.fo.Name = "fo";
            this.fo.Width = 95;
            // 
            // fe
            // 
            this.fe.HeaderText = "FE";
            this.fe.MinimumWidth = 6;
            this.fe.Name = "fe";
            this.fe.Width = 125;
            // 
            // c
            // 
            this.c.HeaderText = "C";
            this.c.MinimumWidth = 6;
            this.c.Name = "c";
            this.c.Width = 125;
            // 
            // cac
            // 
            this.cac.HeaderText = "C(Acumulado)";
            this.cac.MinimumWidth = 6;
            this.cac.Name = "cac";
            this.cac.Width = 130;
            // 
            // chrt_graf
            // 
            chartArea1.Name = "ChartArea1";
            this.chrt_graf.ChartAreas.Add(chartArea1);
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend1.Name = "Legend1";
            this.chrt_graf.Legends.Add(legend1);
            this.chrt_graf.Location = new System.Drawing.Point(696, 414);
            this.chrt_graf.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chrt_graf.Name = "chrt_graf";
            this.chrt_graf.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire;
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Frecuencia Observada";
            this.chrt_graf.Series.Add(series1);
            this.chrt_graf.Size = new System.Drawing.Size(639, 369);
            this.chrt_graf.TabIndex = 19;
            this.chrt_graf.Text = "Histograma";
            // 
            // lbl_resHipotesis
            // 
            this.lbl_resHipotesis.AutoSize = true;
            this.lbl_resHipotesis.BackColor = System.Drawing.Color.Black;
            this.lbl_resHipotesis.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_resHipotesis.ForeColor = System.Drawing.Color.Gold;
            this.lbl_resHipotesis.Location = new System.Drawing.Point(324, 713);
            this.lbl_resHipotesis.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_resHipotesis.Name = "lbl_resHipotesis";
            this.lbl_resHipotesis.Size = new System.Drawing.Size(0, 29);
            this.lbl_resHipotesis.TabIndex = 24;
            // 
            // txtValorTabulado
            // 
            this.txtValorTabulado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtValorTabulado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorTabulado.Location = new System.Drawing.Point(484, 629);
            this.txtValorTabulado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtValorTabulado.Name = "txtValorTabulado";
            this.txtValorTabulado.Size = new System.Drawing.Size(117, 27);
            this.txtValorTabulado.TabIndex = 23;
            // 
            // txtNivelSignificancia
            // 
            this.txtNivelSignificancia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNivelSignificancia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNivelSignificancia.Location = new System.Drawing.Point(484, 526);
            this.txtNivelSignificancia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNivelSignificancia.Name = "txtNivelSignificancia";
            this.txtNivelSignificancia.Size = new System.Drawing.Size(117, 27);
            this.txtNivelSignificancia.TabIndex = 22;
            // 
            // lblValorTabulado
            // 
            this.lblValorTabulado.AutoSize = true;
            this.lblValorTabulado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorTabulado.Location = new System.Drawing.Point(411, 580);
            this.lblValorTabulado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValorTabulado.Name = "lblValorTabulado";
            this.lblValorTabulado.Size = new System.Drawing.Size(178, 29);
            this.lblValorTabulado.TabIndex = 21;
            this.lblValorTabulado.Text = "Valor Tabulado";
            // 
            // lblNivelSignificancia
            // 
            this.lblNivelSignificancia.AutoSize = true;
            this.lblNivelSignificancia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNivelSignificancia.Location = new System.Drawing.Point(379, 466);
            this.lblNivelSignificancia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNivelSignificancia.Name = "lblNivelSignificancia";
            this.lblNivelSignificancia.Size = new System.Drawing.Size(244, 29);
            this.lblNivelSignificancia.TabIndex = 20;
            this.lblNivelSignificancia.Text = "Nivel de Significancia";
            // 
            // gdrSerieAleatoria
            // 
            this.gdrSerieAleatoria.BackgroundColor = System.Drawing.SystemColors.Control;
            this.gdrSerieAleatoria.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gdrSerieAleatoria.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gdrSerieAleatoria.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdrSerieAleatoria.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gdrSerieAleatoria.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdrSerieAleatoria.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iteracion,
            this.rnd});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gdrSerieAleatoria.DefaultCellStyle = dataGridViewCellStyle5;
            this.gdrSerieAleatoria.Location = new System.Drawing.Point(28, 31);
            this.gdrSerieAleatoria.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gdrSerieAleatoria.Name = "gdrSerieAleatoria";
            this.gdrSerieAleatoria.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdrSerieAleatoria.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.gdrSerieAleatoria.RowHeadersVisible = false;
            this.gdrSerieAleatoria.RowHeadersWidth = 51;
            this.gdrSerieAleatoria.Size = new System.Drawing.Size(235, 751);
            this.gdrSerieAleatoria.TabIndex = 15;
            // 
            // iteracion
            // 
            this.iteracion.HeaderText = "Iteracion";
            this.iteracion.MinimumWidth = 6;
            this.iteracion.Name = "iteracion";
            this.iteracion.Width = 80;
            // 
            // rnd
            // 
            this.rnd.HeaderText = "RND";
            this.rnd.MinimumWidth = 6;
            this.rnd.Name = "rnd";
            this.rnd.Width = 125;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkGyK);
            this.groupBox1.Controls.Add(this.checkIncluir1);
            this.groupBox1.Controls.Add(this.TxtTamañoMuestra);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Location = new System.Drawing.Point(28, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(393, 731);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            // 
            // checkGyK
            // 
            this.checkGyK.AutoSize = true;
            this.checkGyK.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkGyK.Location = new System.Drawing.Point(27, 252);
            this.checkGyK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkGyK.Name = "checkGyK";
            this.checkGyK.Size = new System.Drawing.Size(308, 28);
            this.checkGyK.TabIndex = 20;
            this.checkGyK.Text = "¿Utilizar G y K para calculo ideal?";
            this.checkGyK.UseVisualStyleBackColor = true;
            this.checkGyK.CheckedChanged += new System.EventHandler(this.checkGyK_CheckedChanged);
            // 
            // checkIncluir1
            // 
            this.checkIncluir1.AutoSize = true;
            this.checkIncluir1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkIncluir1.Location = new System.Drawing.Point(27, 194);
            this.checkIncluir1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkIncluir1.Name = "checkIncluir1";
            this.checkIncluir1.Size = new System.Drawing.Size(127, 28);
            this.checkIncluir1.TabIndex = 19;
            this.checkIncluir1.Text = "No incluir 1";
            this.checkIncluir1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.TxtG);
            this.groupBox3.Controls.Add(this.TxtK);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.TxtM);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.TxtC);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.TxtA);
            this.groupBox3.Controls.Add(this.TxtXo);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(27, 310);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox3.Size = new System.Drawing.Size(339, 396);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            // 
            // TxtG
            // 
            this.TxtG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtG.Location = new System.Drawing.Point(108, 342);
            this.TxtG.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtG.Name = "TxtG";
            this.TxtG.Size = new System.Drawing.Size(62, 29);
            this.TxtG.TabIndex = 19;
            // 
            // TxtK
            // 
            this.TxtK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtK.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtK.Location = new System.Drawing.Point(108, 286);
            this.TxtK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtK.Name = "TxtK";
            this.TxtK.Size = new System.Drawing.Size(62, 29);
            this.TxtK.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 345);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 24);
            this.label9.TabIndex = 17;
            this.label9.Text = "g";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 288);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 24);
            this.label8.TabIndex = 16;
            this.label8.Text = "k";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(124, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 24);
            this.label3.TabIndex = 11;
            this.label3.Text = "Variables";
            // 
            // TxtM
            // 
            this.TxtM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtM.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtM.Location = new System.Drawing.Point(108, 224);
            this.TxtM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtM.Name = "TxtM";
            this.TxtM.Size = new System.Drawing.Size(62, 29);
            this.TxtM.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 226);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 24);
            this.label7.TabIndex = 15;
            this.label7.Text = "m";
            // 
            // TxtC
            // 
            this.TxtC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtC.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtC.Location = new System.Drawing.Point(108, 165);
            this.TxtC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtC.Name = "TxtC";
            this.TxtC.Size = new System.Drawing.Size(62, 29);
            this.TxtC.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 54);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 24);
            this.label4.TabIndex = 12;
            this.label4.Text = "Xo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 112);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 24);
            this.label5.TabIndex = 13;
            this.label5.Text = "a";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(36, 167);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 24);
            this.label6.TabIndex = 14;
            this.label6.Text = "c";
            // 
            // TxtA
            // 
            this.TxtA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtA.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtA.Location = new System.Drawing.Point(108, 110);
            this.TxtA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtA.Name = "TxtA";
            this.TxtA.Size = new System.Drawing.Size(62, 29);
            this.TxtA.TabIndex = 6;
            // 
            // TxtXo
            // 
            this.TxtXo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtXo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtXo.Location = new System.Drawing.Point(108, 52);
            this.TxtXo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtXo.Name = "TxtXo";
            this.TxtXo.Size = new System.Drawing.Size(62, 29);
            this.TxtXo.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbl_resHipotesis);
            this.groupBox2.Controls.Add(this.txtValorTabulado);
            this.groupBox2.Controls.Add(this.chrt_graf);
            this.groupBox2.Controls.Add(this.lblValorTabulado);
            this.groupBox2.Controls.Add(this.txtNivelSignificancia);
            this.groupBox2.Controls.Add(this.gdrSerieAleatoria);
            this.groupBox2.Controls.Add(this.tabla);
            this.groupBox2.Controls.Add(this.lblNivelSignificancia);
            this.groupBox2.Location = new System.Drawing.Point(443, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(1353, 809);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            // 
            // Chi_CuadradoCM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1823, 838);
            this.Controls.Add(this.btn_limpiar);
            this.Controls.Add(this.btn_volverMenu);
            this.Controls.Add(this.radioButton12);
            this.Controls.Add(this.radioButton8);
            this.Controls.Add(this.radioButton10);
            this.Controls.Add(this.radioButton5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_generar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Chi_CuadradoCM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chi_CuadradoCM";
            this.Load += new System.EventHandler(this.Chi_CuadradoCM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tabla)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chrt_graf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdrSerieAleatoria)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtTamañoMuestra;
        private System.Windows.Forms.Button btn_generar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_volverMenu;
        private System.Windows.Forms.Button btn_limpiar;
        private System.Windows.Forms.DataGridView tabla;
        private System.Windows.Forms.DataGridViewTextBoxColumn desde;
        private System.Windows.Forms.DataGridViewTextBoxColumn hasta;
        private System.Windows.Forms.DataGridViewTextBoxColumn mc;
        private System.Windows.Forms.DataGridViewTextBoxColumn fo;
        private System.Windows.Forms.DataGridViewTextBoxColumn fe;
        private System.Windows.Forms.DataGridViewTextBoxColumn c;
        private System.Windows.Forms.DataGridViewTextBoxColumn cac;
        private System.Windows.Forms.DataVisualization.Charting.Chart chrt_graf;
        private System.Windows.Forms.Label lbl_resHipotesis;
        private System.Windows.Forms.TextBox txtValorTabulado;
        private System.Windows.Forms.TextBox txtNivelSignificancia;
        private System.Windows.Forms.Label lblValorTabulado;
        private System.Windows.Forms.Label lblNivelSignificancia;
        private System.Windows.Forms.DataGridView gdrSerieAleatoria;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox TxtM;
        private System.Windows.Forms.TextBox TxtC;
        private System.Windows.Forms.TextBox TxtA;
        private System.Windows.Forms.TextBox TxtXo;
        private System.Windows.Forms.DataGridViewTextBoxColumn iteracion;
        private System.Windows.Forms.DataGridViewTextBoxColumn rnd;
        private System.Windows.Forms.CheckBox checkGyK;
        private System.Windows.Forms.CheckBox checkIncluir1;
        private System.Windows.Forms.TextBox TxtG;
        private System.Windows.Forms.TextBox TxtK;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
    }
}