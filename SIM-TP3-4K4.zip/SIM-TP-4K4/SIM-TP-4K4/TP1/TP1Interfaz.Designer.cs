﻿namespace SIM_TP_4K4.TP1
{
    partial class TP1_Interfaz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TP1_Interfaz));
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.btn_volverMenu = new System.Windows.Forms.Button();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_generar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxDefecto = new System.Windows.Forms.CheckBox();
            this.checkbxFr = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cbxMetodo = new System.Windows.Forms.ComboBox();
            this.checkGyK = new System.Windows.Forms.CheckBox();
            this.TxtTamañoMuestra = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblSemilla2 = new System.Windows.Forms.Label();
            this.TxtSemilla2 = new System.Windows.Forms.TextBox();
            this.TxtG = new System.Windows.Forms.TextBox();
            this.TxtK = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtM = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtA = new System.Windows.Forms.TextBox();
            this.TxtXo = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gdrSerieAleatoria = new System.Windows.Forms.DataGridView();
            this.orden = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.random = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.btnMas1 = new System.Windows.Forms.Button();
            this.btnMas20 = new System.Windows.Forms.Button();
            this.btnMas10 = new System.Windows.Forms.Button();
            this.btnChi = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnN = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gdrSerieAleatoria)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpiar.Location = new System.Drawing.Point(275, 762);
            this.btn_limpiar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(117, 50);
            this.btn_limpiar.TabIndex = 35;
            this.btn_limpiar.Text = "Limpiar Campos";
            this.btn_limpiar.UseVisualStyleBackColor = true;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // btn_volverMenu
            // 
            this.btn_volverMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volverMenu.Location = new System.Drawing.Point(12, 762);
            this.btn_volverMenu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_volverMenu.Name = "btn_volverMenu";
            this.btn_volverMenu.Size = new System.Drawing.Size(107, 50);
            this.btn_volverMenu.TabIndex = 34;
            this.btn_volverMenu.Text = "Volver al Menu";
            this.btn_volverMenu.UseVisualStyleBackColor = true;
            this.btn_volverMenu.Click += new System.EventHandler(this.btn_volverMenu_Click);
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton12.Location = new System.Drawing.Point(209, 37);
            this.radioButton12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(45, 22);
            this.radioButton12.TabIndex = 30;
            this.radioButton12.Text = "12";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton8.Location = new System.Drawing.Point(83, 37);
            this.radioButton8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(37, 22);
            this.radioButton8.TabIndex = 28;
            this.radioButton8.Text = "8";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Checked = true;
            this.radioButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton10.Location = new System.Drawing.Point(141, 37);
            this.radioButton10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(45, 22);
            this.radioButton10.TabIndex = 29;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "10";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton5.Location = new System.Drawing.Point(24, 37);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(37, 22);
            this.radioButton5.TabIndex = 27;
            this.radioButton5.Text = "5";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 69);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 24);
            this.label1.TabIndex = 31;
            this.label1.Text = "Tamaño de Muestra (N)";
            // 
            // btn_generar
            // 
            this.btn_generar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_generar.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_generar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_generar.Location = new System.Drawing.Point(143, 762);
            this.btn_generar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_generar.Name = "btn_generar";
            this.btn_generar.Size = new System.Drawing.Size(111, 50);
            this.btn_generar.TabIndex = 33;
            this.btn_generar.Text = "Generar";
            this.btn_generar.UseVisualStyleBackColor = false;
            this.btn_generar.Click += new System.EventHandler(this.btn_generar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxDefecto);
            this.groupBox1.Controls.Add(this.checkbxFr);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.cbxMetodo);
            this.groupBox1.Controls.Add(this.checkGyK);
            this.groupBox1.Controls.Add(this.TxtTamañoMuestra);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Location = new System.Drawing.Point(8, 4);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(393, 751);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            // 
            // checkBoxDefecto
            // 
            this.checkBoxDefecto.AutoSize = true;
            this.checkBoxDefecto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDefecto.Location = new System.Drawing.Point(27, 289);
            this.checkBoxDefecto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBoxDefecto.Name = "checkBoxDefecto";
            this.checkBoxDefecto.Size = new System.Drawing.Size(271, 28);
            this.checkBoxDefecto.TabIndex = 41;
            this.checkBoxDefecto.Text = "¿Utilizar valores por defecto?";
            this.checkBoxDefecto.UseVisualStyleBackColor = true;
            this.checkBoxDefecto.CheckedChanged += new System.EventHandler(this.checkBoxDefecto_CheckedChanged);
            // 
            // checkbxFr
            // 
            this.checkbxFr.AutoSize = true;
            this.checkbxFr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkbxFr.Location = new System.Drawing.Point(27, 194);
            this.checkbxFr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkbxFr.Name = "checkbxFr";
            this.checkbxFr.Size = new System.Drawing.Size(270, 28);
            this.checkbxFr.TabIndex = 40;
            this.checkbxFr.Text = "¿Mostrar frecuencia relativa?";
            this.checkbxFr.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButton5);
            this.groupBox4.Controls.Add(this.radioButton8);
            this.groupBox4.Controls.Add(this.radioButton12);
            this.groupBox4.Controls.Add(this.radioButton10);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(27, 110);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(277, 69);
            this.groupBox4.TabIndex = 39;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Seleccionar cantidad intervalos";
            // 
            // cbxMetodo
            // 
            this.cbxMetodo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxMetodo.FormattingEnabled = true;
            this.cbxMetodo.Items.AddRange(new object[] {
            "Seleccionar Metodo",
            "Congruencial Lineal(Mixto)",
            "Congruencial Multiplicativo",
            "Congruencial Aditivo",
            "Generador del Lenguaje"});
            this.cbxMetodo.Location = new System.Drawing.Point(27, 23);
            this.cbxMetodo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxMetodo.Name = "cbxMetodo";
            this.cbxMetodo.Size = new System.Drawing.Size(253, 28);
            this.cbxMetodo.TabIndex = 21;
            this.cbxMetodo.Text = "Seleccionar Metodo";
            this.cbxMetodo.SelectedIndexChanged += new System.EventHandler(this.chequearMetodo);
            // 
            // checkGyK
            // 
            this.checkGyK.AutoSize = true;
            this.checkGyK.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkGyK.Location = new System.Drawing.Point(27, 240);
            this.checkGyK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkGyK.Name = "checkGyK";
            this.checkGyK.Size = new System.Drawing.Size(308, 28);
            this.checkGyK.TabIndex = 20;
            this.checkGyK.Text = "¿Utilizar G y K para calculo ideal?";
            this.checkGyK.UseVisualStyleBackColor = true;
            this.checkGyK.CheckedChanged += new System.EventHandler(this.checkGyK_CheckedChanged);
            // 
            // TxtTamañoMuestra
            // 
            this.TxtTamañoMuestra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtTamañoMuestra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTamañoMuestra.Location = new System.Drawing.Point(260, 66);
            this.TxtTamañoMuestra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtTamañoMuestra.Name = "TxtTamañoMuestra";
            this.TxtTamañoMuestra.Size = new System.Drawing.Size(67, 29);
            this.TxtTamañoMuestra.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblSemilla2);
            this.groupBox3.Controls.Add(this.TxtSemilla2);
            this.groupBox3.Controls.Add(this.TxtG);
            this.groupBox3.Controls.Add(this.TxtK);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.TxtM);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.TxtC);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.TxtA);
            this.groupBox3.Controls.Add(this.TxtXo);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(27, 338);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox3.Size = new System.Drawing.Size(339, 396);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            // 
            // lblSemilla2
            // 
            this.lblSemilla2.AutoSize = true;
            this.lblSemilla2.Enabled = false;
            this.lblSemilla2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSemilla2.Location = new System.Drawing.Point(187, 54);
            this.lblSemilla2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSemilla2.Name = "lblSemilla2";
            this.lblSemilla2.Size = new System.Drawing.Size(51, 24);
            this.lblSemilla2.TabIndex = 21;
            this.lblSemilla2.Text = "Xo-1";
            this.lblSemilla2.Visible = false;
            // 
            // TxtSemilla2
            // 
            this.TxtSemilla2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtSemilla2.Enabled = false;
            this.TxtSemilla2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSemilla2.Location = new System.Drawing.Point(257, 52);
            this.TxtSemilla2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtSemilla2.Name = "TxtSemilla2";
            this.TxtSemilla2.Size = new System.Drawing.Size(62, 29);
            this.TxtSemilla2.TabIndex = 20;
            this.TxtSemilla2.Visible = false;
            // 
            // TxtG
            // 
            this.TxtG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtG.Location = new System.Drawing.Point(108, 342);
            this.TxtG.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtG.Name = "TxtG";
            this.TxtG.Size = new System.Drawing.Size(62, 29);
            this.TxtG.TabIndex = 19;
            // 
            // TxtK
            // 
            this.TxtK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtK.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtK.Location = new System.Drawing.Point(108, 286);
            this.TxtK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtK.Name = "TxtK";
            this.TxtK.Size = new System.Drawing.Size(62, 29);
            this.TxtK.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 345);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 24);
            this.label9.TabIndex = 17;
            this.label9.Text = "g";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 288);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 24);
            this.label8.TabIndex = 16;
            this.label8.Text = "k";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(124, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 24);
            this.label3.TabIndex = 11;
            this.label3.Text = "Variables";
            // 
            // TxtM
            // 
            this.TxtM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtM.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtM.Location = new System.Drawing.Point(108, 224);
            this.TxtM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtM.Name = "TxtM";
            this.TxtM.Size = new System.Drawing.Size(62, 29);
            this.TxtM.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 226);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 24);
            this.label7.TabIndex = 15;
            this.label7.Text = "m";
            // 
            // TxtC
            // 
            this.TxtC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtC.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtC.Location = new System.Drawing.Point(108, 165);
            this.TxtC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtC.Name = "TxtC";
            this.TxtC.Size = new System.Drawing.Size(62, 29);
            this.TxtC.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 54);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 24);
            this.label4.TabIndex = 12;
            this.label4.Text = "Xo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 112);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 24);
            this.label5.TabIndex = 13;
            this.label5.Text = "a";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(36, 167);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 24);
            this.label6.TabIndex = 14;
            this.label6.Text = "c";
            // 
            // TxtA
            // 
            this.TxtA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtA.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtA.Location = new System.Drawing.Point(108, 110);
            this.TxtA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtA.Name = "TxtA";
            this.TxtA.Size = new System.Drawing.Size(62, 29);
            this.TxtA.TabIndex = 6;
            // 
            // TxtXo
            // 
            this.TxtXo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TxtXo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtXo.Location = new System.Drawing.Point(108, 52);
            this.TxtXo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtXo.Name = "TxtXo";
            this.TxtXo.Size = new System.Drawing.Size(62, 29);
            this.TxtXo.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gdrSerieAleatoria);
            this.groupBox2.Location = new System.Drawing.Point(423, 4);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(1353, 500);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            // 
            // gdrSerieAleatoria
            // 
            this.gdrSerieAleatoria.BackgroundColor = System.Drawing.SystemColors.Control;
            this.gdrSerieAleatoria.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gdrSerieAleatoria.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gdrSerieAleatoria.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdrSerieAleatoria.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gdrSerieAleatoria.ColumnHeadersHeight = 29;
            this.gdrSerieAleatoria.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orden,
            this.entero,
            this.random});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gdrSerieAleatoria.DefaultCellStyle = dataGridViewCellStyle2;
            this.gdrSerieAleatoria.Location = new System.Drawing.Point(8, 11);
            this.gdrSerieAleatoria.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gdrSerieAleatoria.Name = "gdrSerieAleatoria";
            this.gdrSerieAleatoria.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdrSerieAleatoria.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gdrSerieAleatoria.RowHeadersVisible = false;
            this.gdrSerieAleatoria.RowHeadersWidth = 51;
            this.gdrSerieAleatoria.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gdrSerieAleatoria.Size = new System.Drawing.Size(1337, 481);
            this.gdrSerieAleatoria.TabIndex = 15;
            // 
            // orden
            // 
            this.orden.HeaderText = "Orden";
            this.orden.MinimumWidth = 6;
            this.orden.Name = "orden";
            this.orden.Width = 125;
            // 
            // entero
            // 
            this.entero.HeaderText = "X";
            this.entero.MinimumWidth = 6;
            this.entero.Name = "entero";
            this.entero.Width = 125;
            // 
            // random
            // 
            this.random.HeaderText = "RND";
            this.random.MinimumWidth = 6;
            this.random.Name = "random";
            this.random.Width = 125;
            // 
            // btnMas1
            // 
            this.btnMas1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMas1.Enabled = false;
            this.btnMas1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnMas1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMas1.Location = new System.Drawing.Point(41, 34);
            this.btnMas1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMas1.Name = "btnMas1";
            this.btnMas1.Size = new System.Drawing.Size(111, 50);
            this.btnMas1.TabIndex = 38;
            this.btnMas1.Text = "+1";
            this.btnMas1.UseVisualStyleBackColor = false;
            this.btnMas1.Click += new System.EventHandler(this.btnMas1_Click);
            // 
            // btnMas20
            // 
            this.btnMas20.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMas20.Enabled = false;
            this.btnMas20.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnMas20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMas20.Location = new System.Drawing.Point(197, 34);
            this.btnMas20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMas20.Name = "btnMas20";
            this.btnMas20.Size = new System.Drawing.Size(111, 50);
            this.btnMas20.TabIndex = 39;
            this.btnMas20.Text = "+20";
            this.btnMas20.UseVisualStyleBackColor = false;
            this.btnMas20.Click += new System.EventHandler(this.btnMas20_Click);
            // 
            // btnMas10
            // 
            this.btnMas10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMas10.Enabled = false;
            this.btnMas10.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnMas10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMas10.Location = new System.Drawing.Point(353, 34);
            this.btnMas10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMas10.Name = "btnMas10";
            this.btnMas10.Size = new System.Drawing.Size(111, 50);
            this.btnMas10.TabIndex = 40;
            this.btnMas10.Text = "+10.000 ";
            this.btnMas10.UseVisualStyleBackColor = false;
            this.btnMas10.Click += new System.EventHandler(this.btnMas10_Click);
            // 
            // btnChi
            // 
            this.btnChi.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnChi.Enabled = false;
            this.btnChi.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChi.Location = new System.Drawing.Point(905, 715);
            this.btnChi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnChi.Name = "btnChi";
            this.btnChi.Size = new System.Drawing.Size(348, 59);
            this.btnChi.TabIndex = 41;
            this.btnChi.Text = "Realizar Test de Chi Cuadrado";
            this.btnChi.UseVisualStyleBackColor = false;
            this.btnChi.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnN);
            this.groupBox5.Controls.Add(this.btnMas1);
            this.groupBox5.Controls.Add(this.btnMas20);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.btnMas10);
            this.groupBox5.Location = new System.Drawing.Point(749, 538);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Size = new System.Drawing.Size(660, 114);
            this.groupBox5.TabIndex = 42;
            this.groupBox5.TabStop = false;
            // 
            // btnN
            // 
            this.btnN.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnN.Enabled = false;
            this.btnN.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnN.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnN.Location = new System.Drawing.Point(509, 34);
            this.btnN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnN.Name = "btnN";
            this.btnN.Size = new System.Drawing.Size(111, 50);
            this.btnN.TabIndex = 44;
            this.btnN.Text = "Hasta N";
            this.btnN.UseVisualStyleBackColor = false;
            this.btnN.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(228, -4);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 24);
            this.label2.TabIndex = 43;
            this.label2.Text = "Agregar Simulaciones";
            // 
            // TP1_Interfaz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1795, 830);
            this.Controls.Add(this.btnChi);
            this.Controls.Add(this.btn_limpiar);
            this.Controls.Add(this.btn_volverMenu);
            this.Controls.Add(this.btn_generar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "TP1_Interfaz";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TP1 - Generacion de Numeros Aleatorios";
            this.Load += new System.EventHandler(this.TP1_Interfaz_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gdrSerieAleatoria)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_limpiar;
        private System.Windows.Forms.Button btn_volverMenu;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_generar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkGyK;
        private System.Windows.Forms.TextBox TxtTamañoMuestra;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox TxtG;
        private System.Windows.Forms.TextBox TxtK;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtM;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TxtC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TxtA;
        private System.Windows.Forms.TextBox TxtXo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView gdrSerieAleatoria;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ComboBox cbxMetodo;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridViewTextBoxColumn orden;
        private System.Windows.Forms.DataGridViewTextBoxColumn entero;
        private System.Windows.Forms.DataGridViewTextBoxColumn random;
        private System.Windows.Forms.Button btnMas1;
        private System.Windows.Forms.Button btnMas20;
        private System.Windows.Forms.Button btnMas10;
        private System.Windows.Forms.CheckBox checkbxFr;
        private System.Windows.Forms.Label lblSemilla2;
        private System.Windows.Forms.TextBox TxtSemilla2;
        private System.Windows.Forms.CheckBox checkBoxDefecto;
        private System.Windows.Forms.Button btnChi;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnN;
    }
}