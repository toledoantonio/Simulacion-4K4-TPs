﻿namespace SIM_TP_4K4
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuPrincipal));
            this.btn_menuPrincipal = new System.Windows.Forms.Button();
            this.btn3_MenuPrincipal = new System.Windows.Forms.Button();
            this.txt_Menu = new System.Windows.Forms.Label();
            this.txt_Nombres = new System.Windows.Forms.Label();
            this.txtNombres2 = new System.Windows.Forms.Label();
            this.txtNombres3 = new System.Windows.Forms.Label();
            this.txtNombres4 = new System.Windows.Forms.Label();
            this.txtNombres5 = new System.Windows.Forms.Label();
            this.txtMenu = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn4_MenuPrincipal = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_menuPrincipal
            // 
            this.btn_menuPrincipal.BackColor = System.Drawing.Color.SlateGray;
            this.btn_menuPrincipal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_menuPrincipal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_menuPrincipal.Location = new System.Drawing.Point(150, 35);
            this.btn_menuPrincipal.Name = "btn_menuPrincipal";
            this.btn_menuPrincipal.Size = new System.Drawing.Size(170, 56);
            this.btn_menuPrincipal.TabIndex = 13;
            this.btn_menuPrincipal.Text = "TP1";
            this.btn_menuPrincipal.UseVisualStyleBackColor = false;
            this.btn_menuPrincipal.Click += new System.EventHandler(this.btn_menuPrincipal_Click);
            // 
            // btn3_MenuPrincipal
            // 
            this.btn3_MenuPrincipal.BackColor = System.Drawing.Color.SlateGray;
            this.btn3_MenuPrincipal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3_MenuPrincipal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn3_MenuPrincipal.Location = new System.Drawing.Point(150, 34);
            this.btn3_MenuPrincipal.Name = "btn3_MenuPrincipal";
            this.btn3_MenuPrincipal.Size = new System.Drawing.Size(170, 58);
            this.btn3_MenuPrincipal.TabIndex = 15;
            this.btn3_MenuPrincipal.Text = "TP3";
            this.btn3_MenuPrincipal.UseVisualStyleBackColor = false;
            this.btn3_MenuPrincipal.Click += new System.EventHandler(this.btn3_MenuPrincipal_Click);
            // 
            // txt_Menu
            // 
            this.txt_Menu.AutoSize = true;
            this.txt_Menu.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Menu.Location = new System.Drawing.Point(289, 5);
            this.txt_Menu.Name = "txt_Menu";
            this.txt_Menu.Size = new System.Drawing.Size(156, 30);
            this.txt_Menu.TabIndex = 16;
            this.txt_Menu.Text = "Menu Principal";
            this.txt_Menu.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_Nombres
            // 
            this.txt_Nombres.AutoSize = true;
            this.txt_Nombres.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nombres.Location = new System.Drawing.Point(54, 209);
            this.txt_Nombres.Name = "txt_Nombres";
            this.txt_Nombres.Size = new System.Drawing.Size(160, 17);
            this.txt_Nombres.TabIndex = 17;
            this.txt_Nombres.Text = "Bendezu Jonathan (82425)";
            // 
            // txtNombres2
            // 
            this.txtNombres2.AutoSize = true;
            this.txtNombres2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombres2.Location = new System.Drawing.Point(54, 238);
            this.txtNombres2.Name = "txtNombres2";
            this.txtNombres2.Size = new System.Drawing.Size(146, 17);
            this.txtNombres2.TabIndex = 18;
            this.txtNombres2.Text = "Monutti Gabriel (88982)";
            // 
            // txtNombres3
            // 
            this.txtNombres3.AutoSize = true;
            this.txtNombres3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombres3.Location = new System.Drawing.Point(54, 267);
            this.txtNombres3.Name = "txtNombres3";
            this.txtNombres3.Size = new System.Drawing.Size(158, 17);
            this.txtNombres3.TabIndex = 19;
            this.txtNombres3.Text = "Rey Nores Mateo (74939)";
            // 
            // txtNombres4
            // 
            this.txtNombres4.AutoSize = true;
            this.txtNombres4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombres4.Location = new System.Drawing.Point(54, 296);
            this.txtNombres4.Name = "txtNombres4";
            this.txtNombres4.Size = new System.Drawing.Size(147, 17);
            this.txtNombres4.TabIndex = 20;
            this.txtNombres4.Text = "Simbero Franco (82281)";
            // 
            // txtNombres5
            // 
            this.txtNombres5.AutoSize = true;
            this.txtNombres5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombres5.Location = new System.Drawing.Point(54, 326);
            this.txtNombres5.Name = "txtNombres5";
            this.txtNombres5.Size = new System.Drawing.Size(144, 17);
            this.txtNombres5.TabIndex = 21;
            this.txtNombres5.Text = "Toledo Antonio (81864)";
            // 
            // txtMenu
            // 
            this.txtMenu.AutoSize = true;
            this.txtMenu.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMenu.Location = new System.Drawing.Point(4, 55);
            this.txtMenu.Name = "txtMenu";
            this.txtMenu.Size = new System.Drawing.Size(204, 30);
            this.txtMenu.TabIndex = 22;
            this.txtMenu.Text = "Catedra: Simulación";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SIM_TP_4K4.Properties.Resources.logo_utn_frc;
            this.pictureBox1.Location = new System.Drawing.Point(483, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(232, 171);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(537, 299);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 17);
            this.label1.TabIndex = 25;
            this.label1.Text = "Barale, Lorena Natalia";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(537, 272);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 17);
            this.label2.TabIndex = 26;
            this.label2.Text = "Berrotaran, Juan Jose";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(537, 245);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 17);
            this.label3.TabIndex = 27;
            this.label3.Text = "Castro, Sergio Horacio";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 30);
            this.label4.TabIndex = 28;
            this.label4.Text = "Docentes";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 30);
            this.label5.TabIndex = 29;
            this.label5.Text = "Grupo:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.IndianRed;
            this.label6.Location = new System.Drawing.Point(75, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 31);
            this.label6.TabIndex = 30;
            this.label6.Text = "B";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txt_Nombres);
            this.groupBox1.Controls.Add(this.txtNombres5);
            this.groupBox1.Controls.Add(this.txtNombres2);
            this.groupBox1.Controls.Add(this.txtNombres4);
            this.groupBox1.Controls.Add(this.txtNombres3);
            this.groupBox1.Location = new System.Drawing.Point(483, 189);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 364);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.btn_menuPrincipal);
            this.groupBox2.Location = new System.Drawing.Point(9, 189);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(465, 109);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(112, -5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(253, 21);
            this.label7.TabIndex = 35;
            this.label7.Text = "Generación de Números Aleatorios";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn3_MenuPrincipal);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(9, 316);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(465, 109);
            this.groupBox3.TabIndex = 33;
            this.groupBox3.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(165, -4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(146, 21);
            this.label8.TabIndex = 36;
            this.label8.Text = "Variables Aleatorias";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn4_MenuPrincipal);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(9, 443);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(465, 109);
            this.groupBox4.TabIndex = 34;
            this.groupBox4.TabStop = false;
            // 
            // btn4_MenuPrincipal
            // 
            this.btn4_MenuPrincipal.BackColor = System.Drawing.Color.SlateGray;
            this.btn4_MenuPrincipal.Enabled = false;
            this.btn4_MenuPrincipal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4_MenuPrincipal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn4_MenuPrincipal.Location = new System.Drawing.Point(150, 33);
            this.btn4_MenuPrincipal.Name = "btn4_MenuPrincipal";
            this.btn4_MenuPrincipal.Size = new System.Drawing.Size(170, 58);
            this.btn4_MenuPrincipal.TabIndex = 38;
            this.btn4_MenuPrincipal.Text = "TP4";
            this.btn4_MenuPrincipal.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(143, -4);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(191, 21);
            this.label9.TabIndex = 37;
            this.label9.Text = "Simulación de Montecarlo";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(4, 99);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 30);
            this.label10.TabIndex = 35;
            this.label10.Text = "Curso: 4K4";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(4, 143);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 30);
            this.label11.TabIndex = 36;
            this.label11.Text = "Año: 2022";
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(727, 565);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtMenu);
            this.Controls.Add(this.txt_Menu);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MenuPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Principal";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_menuPrincipal;
        private System.Windows.Forms.Button btn3_MenuPrincipal;
        private System.Windows.Forms.Label txt_Menu;
        private System.Windows.Forms.Label txt_Nombres;
        private System.Windows.Forms.Label txtNombres2;
        private System.Windows.Forms.Label txtNombres3;
        private System.Windows.Forms.Label txtNombres4;
        private System.Windows.Forms.Label txtNombres5;
        private System.Windows.Forms.Label txtMenu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn4_MenuPrincipal;
    }
}

